import React from 'react'
// import Testtodo from "./component/testtodo";
import Todo from "./component/todo";

const App = () => {
  return (
    <>
      <Todo />
    </>
  )
}

export default App
